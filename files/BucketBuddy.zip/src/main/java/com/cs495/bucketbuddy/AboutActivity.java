package com.cs495.bucketbuddy;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by Rafael on 3/30/15.
 */
public class AboutActivity extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

    }
}
